(function (g) {
  'use strict';
  const A = g.HBFAuthoring;
  const escape = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  function mount(host, draft, callbacks) {
    A.validate(draft);
    const root = host.shadowRoot || host.attachShadow({ mode: 'open' });
    if (draft.kind === 'memo') {
      root.innerHTML = '<style>' + g.HBFAuthoringShell.css + '</style>' + g.HBFAuthoringShell.html;
      root.getElementById('analysis-tools').onclick = callbacks.onTools;
      const controller = g.HBFTemplateUI.mount(root, {
        embedded: true, state: draft.content,
        onChange: content => { draft.content = content; callbacks.onChange(); },
        onSave: callbacks.onSave, onOpen: callbacks.onOpen, onNew: callbacks.onNew, onExport: callbacks.onExport
      });
      const jump=root.getElementById('section-jump');
      jump.innerHTML=Array.from(root.getElementById('section-nav').querySelectorAll('a')).map(link=>'<option value="'+escape(link.getAttribute('href').slice(1))+'">'+escape(link.textContent)+'</option>').join('');
      jump.onchange=()=>{const target=root.getElementById(jump.value);target?.scrollIntoView({block:'start'});(target?.matches('[contenteditable],input,textarea,select')?target:target?.querySelector('[contenteditable],input,textarea,select'))?.focus({preventScroll:true});};
      return controller;
    }
    return g.HBFQPRUI.mount(root, draft, callbacks);
  }
  g.HBFAuthoringUI = { mount };
})(globalThis);
