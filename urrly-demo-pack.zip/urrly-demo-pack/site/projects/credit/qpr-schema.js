(function(g){
  'use strict';
  // Labels and order follow the supplied HBF monitor Summary. Specimen answers
  // are not template defaults. All amounts, terms, and dates remain typable.
  const sections=[
    ['borrower','Borrower Information'],['facility','Facility Information'],['appraisal','Project Appraisal'],['release','Release Terms'],['progress','A&D Progress and Interest Reserve'],['ratings','Risk Ratings / Policy Exceptions / Reviews'],['advance','Advance Rates and Extension Terms'],['relationship','Relationship Comments'],['banking','Banking Relationship Summary'],['borrowerTracking','Borrower Tracking Items'],['guarantorTracking','Guarantor(s) Tracking Items'],['income','Financial Statement Analysis ($000s)'],['balance','Quarterly Balance Sheet Summary ($000s)'],['covenants','Covenant Summary ($000s)'],['curtailment','Curtailment Schedule'],['financial','Financial Commentary'],['support','Inventory and Sales / Closings'],['conclusion','PM Conclusion and Follow-up Actions']
  ];
  const appendices=[['heatMap','Heat Map'],['budget','Budget vs. Actual'],['statements','Financial Statement Spreads'],['portfolio','Quarterly PR — Portfolio Schedule'],['ratios','Ratio Analysis'],['other','Other Exhibits'],['notes','Monitor Notes for PM/RM']];
  const fields=[];
  const add=(section,entries)=>entries.forEach(([key,label,cell,format])=>fields.push({key,label,section,cell:cell||'',format:format||'text'}));
  add('borrower',[
    ['rmPm','RM / PM:','C5'],['upb','Current UPB:','F5','money'],['relationship','Relationship Name:','C6'],['exposure','Rel. Exposure:','F6','money'],['borrower','Borrower Name:','C7'],['deposits','Rel. Deposits:','F7','money'],['obligor','Obligor Number:','C8'],['cra','CRA (Y/N):','F8'],['headquarters','Borrower HQ:','C9'],['established','Established:','F9'],['guarantors','Guarantor(s):','C10'],['guarantyAmount','Grt. Amount:','C11'],['relatedEntities','Related Entities:','C12']
  ]);
  add('facility',[
    ['facilityType','Facility Type:','C15'],['secured','Secured (Y/N):','F15'],['approved','Date Approved:','C16','date'],['closed','Closed:','F16','date'],['lineMaturity','Line Maturity:','C17','date'],['noteMaturity','Note Maturity:','F17','date'],['lineDays','Days Till Line Maturity:','C18','days'],['finalMaturity','Final Maturity:','F18','days'],['grossAmount','Gross Amount:','C19','money'],['netAmount','Net Amount:','F19','money'],['interestRate','Interest Rate:','C20'],['interestFloor','Interest Floor:','F20'],['syndication','Syndication:','C21'],['hold','% Hold:','F21','percent'],['markets','Markets:','C22'],['collateral','Collateral:','C23'],['purpose','Use of Proceeds:','C24']
  ]);
  add('appraisal',[
    ['appraisalDate','Appraisal Date:','J15','date'],['asIs','"As is" Value:','J16','money'],['asComplete','"Upon Completion" Value:','J17','money'],['appraisalAbsorption','Appraisal Absorption:','J18'],['borrowerProjection','Borrower Projection:','J19'],['actualAbsorption','Actual Absorption:','J20']
  ]);
  add('release',[
    ['releasePrice','Release Price:','O15'],['acceleration','Acceleration:','O16'],['collateralUnits','Collateral Units:','O17'],['payoffUnits','Units Required for Payoff:','O18'],['projectClosings','Project Closings to Date:','O19'],['unitsUntilPayoff','Units Until Payoff:','O20']
  ]);
  add('progress',[
    ['adComplete','% A&D Complete:','J23','percent'],['completionDate','Estim. Completion Date:','J24','date'],['reserve','Reserve:','N23','money'],['remainingReserve','Remaining:','P23','money'],['fundedReserve','Funded:','N24','money'],['remainingPercent','% Remaining:','P24','percent']
  ]);
  add('ratings',[
    ['tier','Borrower Tier:','C27'],['updated','Last Updated:','F27','date'],['currentRating','BRR (PG-LGD):','C28'],['updatedBy','Last Updated by:','F28'],['recommendedRating','Recomnd BRR (PG-LGD):','C29'],['lastReview','Last Portfolio Review:','F29','date'],['policyException','Policy Exception','C30']
  ]);
  const tables=[];
  const table=(id,section,label,headers,rows,source)=>tables.push({id,section,label,headers,rows,source:source||''});
  table('advance','advance','Advance Rates and Extension Terms',['Type','LTV','LTC','Term','1st Ext.','Reduction','2nd Ext.','Reduction'],['Entitled Land','LUD','Finished Lots','Models','Spec','Sold'].map(x=>[x,'','','','','','','']),'Summary!H27:P33');
  table('banking','banking','Borrower Banking Summary: UPB, Utilization & Deposits',['Period end','Gross commitment ($)','Net commitment ($)','UPB ($)','Utilization (%)','Deposits ($)'],[['','','','','','']],'Tracking & Banking');
  const tracking=['Type','Frequency','# Days',"Last Rec’d",'Next Due','Due Date','Days till Due'];
  table('borrowerTracking','borrowerTracking','Borrower Tracking Items',tracking,Array.from({length:5},()=>Array(7).fill('')),'Summary!B52:I57');
  table('guarantorTracking','guarantorTracking','Guarantor(s) Tracking Items',tracking,Array.from({length:7},()=>Array(7).fill('')),'Summary!B61:I68');
  const incomeRows=['Revenue','Average Unit Price','Gross Profit','% Gross Margin','Operating Expenses','% Opex of Revenue','Net Profit','% Net Margin','Unit Closings','Unit Sales','Breakeven Unit Closings','Velocity %'];
  table('quarterly','income','Quarterly Income Statement ($000s)',['Metric','Quarter end','Quarter end','Quarter end','Quarter end'],incomeRows.map(x=>[x,'','','','']),'Summary!B72:F86');
  table('ytd','income','Year-to-Date Income Statement ($000s)',['Metric','Prior YTD end','Current YTD end','Variance ($ / units)','Variance (%)'],incomeRows.map(x=>[x,'','','','']),'Summary!H72:K86');
  table('ttm','income','Trailing Twelve Months Income Statement ($000s)',['Metric','Prior TTM end','Current TTM end','Variance ($ / units)','Variance (%)'],incomeRows.map(x=>[x,'','','','']),'Summary!M72:P86');
  table('balance','balance','Quarterly Balance Sheet Summary ($000s)',['Metric','Quarter end','Quarter end','Quarter end','Quarter end'],['Cash & Equivalent','Current Assets','Total Assets','Current Liabilities','Total Liabilities','Total Net Worth','Intangibles (Bank)','Tangible Net Worth','Subordinated Debt','Effective TNW'].map(x=>[x,'','','','']),'Summary!B88:F99');
  table('covenants','covenants','Covenant Summary ($000s)',['Type','Br / Grt.','Covenant','Measured amount / period','Compliant?','Cushion','Cushion %'],Array.from({length:7},()=>Array(7).fill('')),'Summary!H89:P96');
  table('curtailment','curtailment','Curtailment Schedule',['Pacing Type','Testing Date','Covenant','Actual / period','Proj. Pace','Days till Test','On Pace?'],Array.from({length:3},()=>Array(7).fill('')),'Summary!H100:P103');
  table('inventory','support','Global Inventory Status',['Period end','Sold U/C','Sold CO','Backlog','Spec U/C','Spec CO','Models','Total units','Total with backlog'],[Array(9).fill('')],'Inventory');
  table('globalSales','support','Global Net Sales and Closings',['Period end','Net sales','Cancellations','Closings'],[Array(4).fill('')],'Inventory');
  table('projectSales','support','Project Net Sales and Closings',['Period end','Net sales','Closings'],[['','','']],'Inventory');
  table('lots','support','Global Lot Inventory & Months of Supply',['Period end','Lots owned & controlled','Avg. TTM monthly closings','Months of supply'],[Array(4).fill('')],'Inventory');
  table('units','support','Global Unit Inventory & Months of Supply',['Period end','Units in inventory','Avg. TTM monthly closings','Inventory MOS','Spec MOS','Completed spec MOS'],[Array(6).fill('')],'Inventory');
  table('followup','conclusion','Follow-up Actions',['Action','Owner','Due date','Status','Evidence / follow-up'],[Array(5).fill('')],'PM action register');
  const dates=[['review','Review as-of date'],['financial','Latest Financial Reporting Date'],['inventory','Latest Inventory Reporting Date']];
  g.HBFQPRSchema={sections,appendices,fields,tables,dates};
})(globalThis);
