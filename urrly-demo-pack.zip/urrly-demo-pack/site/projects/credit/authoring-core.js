(function (g) {
  'use strict';
  // Draft text is PM-authored. It never becomes an imported/verified fact.
  const QPR_SECTIONS = Object.freeze([
    ['borrower', 'Borrower Information'],
    ['facility', 'Facility Information'],
    ['appraisal', 'Project Appraisal'],
    ['release', 'Release Terms'],
    ['progress', 'A&D Progress and Interest Reserve'],
    ['ratings', 'Risk Ratings / Policy Exceptions / Reviews'],
    ['advance', 'Advance Rates and Extension Terms'],
    ['relationship', 'Relationship Comments'],
    ['banking', 'Banking Relationship Summary'],
    ['borrowerTracking', 'Borrower Tracking Items'],
    ['guarantorTracking', 'Guarantor(s) Tracking Items'],
    ['income', 'Quarterly / YTD / TTM Income Statement'],
    ['balance', 'Quarterly Balance Sheet Summary ($000s)'],
    ['covenants', 'Covenant Summary'],
    ['curtailment', 'Curtailment Schedule'],
    ['financial', 'Financial Commentary'],
    ['support', 'Inventory, Sales / Closings and Supporting Schedules'],
    ['conclusion', 'PM Conclusion and Follow-up Actions']
  ].map(Object.freeze));
  const QPR_FIELDS = Object.freeze([
    ['borrower', 'Borrower'], ['relationship', 'Relationship'],
    ['obligor', 'Obligor number'], ['rm', 'Relationship Manager'], ['pm', 'Portfolio Manager']
  ].map(Object.freeze));
  const DATE_FIELDS = Object.freeze([
    ['review', 'Review as-of date'], ['financial', 'Financial period end'], ['inventory', 'Inventory period end']
  ].map(Object.freeze));
  const clone = value => JSON.parse(JSON.stringify(value));
  function text(value) {
    if (typeof value !== 'string' || /[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFE\uFFFF\uD800-\uDFFF]/u.test(value)) throw new Error('The draft contains unsupported text.');
  }
  function exact(value, names, label) {
    if (!value || Array.isArray(value) || typeof value !== 'object' || Object.keys(value).sort().join('|') !== names.slice().sort().join('|')) throw new Error(label + ' has an unsupported structure.');
  }
  function validDate(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const d = new Date(value + 'T00:00:00Z');
    return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === value;
  }
  function create(workflow) {
    const kind = workflow === 'portfolio_monitor' ? 'qpr' : 'memo';
    return {
      version: kind === 'qpr' ? '1.1' : '1.0', kind,
      content: kind === 'memo' ? g.HBFTemplate.create() : g.HBFQPR.create()
    };
  }
  function validate(draft, workflow) {
    exact(draft, ['version', 'kind', 'content'], 'Document draft');
    if (!['memo', 'qpr'].includes(draft.kind) || !['1.0', ...(draft.kind === 'qpr' ? ['1.1'] : [])].includes(draft.version)) throw new Error('Open this working file in the Studio version that created it.');
    if (workflow && draft.kind !== (workflow === 'portfolio_monitor' ? 'qpr' : 'memo')) throw new Error('The saved document does not match its workflow.');
    if (draft.kind === 'memo') g.HBFTemplate.validate(draft.content);
    else if (draft.version === '1.1') g.HBFQPR.validate(draft.content);
    else {
      const c = draft.content;
      exact(c, ['title', 'fields', 'dates', 'narratives'], 'QPR draft'); text(c.title);
      exact(c.fields, QPR_FIELDS.map(([k]) => k), 'QPR details');
      exact(c.dates, DATE_FIELDS.map(([k]) => k), 'QPR dates');
      exact(c.narratives, QPR_SECTIONS.map(([k]) => k), 'QPR sections');
      Object.values(c.fields).forEach(text); Object.values(c.narratives).forEach(text);
      for (const value of Object.values(c.dates)) if (value !== '' && !validDate(value)) throw new Error('Enter a real reporting date or leave it blank.');
    }
    return draft;
  }
  function title(draft) {
    return draft.kind === 'memo' ? g.HBFTemplate.get(draft.content, 'control0') : draft.content.title;
  }
  function borrower(draft) {
    return draft.kind === 'memo' ? g.HBFTemplate.get(draft.content, 'p19') : draft.content.fields.borrower;
  }
  function setQPR(draft, group, key, value) {
    if (draft.kind === 'qpr' && draft.version === '1.1') return g.HBFQPR.set(draft.content, group, key, value);
    text(value);
    if (draft.kind !== 'qpr') throw new Error('Choose a quarterly review.');
    if (group === 'title' && key === 'title') draft.content.title = value;
    else if (['fields', 'dates', 'narratives'].includes(group) && Object.hasOwn(draft.content[group], key)) {
      if (group === 'dates' && value !== '' && !validDate(value)) throw new Error('Enter a real date or leave it blank.');
      draft.content[group][key] = value;
    } else throw new Error('Choose an editable QPR field.');
  }
  function upgrade(input) {
    validate(input);
    if (input.kind === 'qpr' && input.version === '1.0') return { version: '1.1', kind: 'qpr', content: g.HBFQPR.migrate(input.content) };
    return clone(input);
  }
  async function exportBytes(draft, context) {
    validate(draft);
    return draft.kind === 'memo' ? g.HBFTemplate.exportBytes(draft.content) : g.HBFQPR.exportBytes(upgrade(draft).content, context);
  }
  g.HBFAuthoring = { create, validate, upgrade, title, borrower, setQPR, validDate, exportBytes, QPR_SECTIONS, QPR_FIELDS, DATE_FIELDS };
})(globalThis);
