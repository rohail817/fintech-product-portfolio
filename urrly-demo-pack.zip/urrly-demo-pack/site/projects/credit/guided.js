(function () {
  "use strict";

  const STAGE_ORDER = Object.freeze(["add", "verify", "judgment", "review", "deliver"]);
  const WORKFLOWS = Object.freeze({
    credit_action: Object.freeze({
      label: "Credit memo",
      stages: Object.freeze({
        add: Object.freeze({ label: "Add documents", title: "Choose scope and add two file types", description: "Add one HBF workbook, then one or more reviewed evidence JSON packets from internal Opus." }),
        verify: Object.freeze({ label: "Confirm what matters", title: "Review imported data", description: "Confirm entities, dates and candidate facts; resolve competing values without losing either source." }),
        judgment: Object.freeze({ label: "Add PM judgment", title: "Analyze the credit", description: "Complete the transaction analysis, downside, risk protections, conditions and PM-owned rating judgment." }),
        review: Object.freeze({ label: "Review draft", title: "Challenge the memo", description: "Read the decision view and every memo section as the Credit Officer will see them." }),
        deliver: Object.freeze({ label: "Download Word memo", title: "Final check and required output", description: "Clear the exact readiness controls, attest to the current revision and download the required Word memo; other outputs remain optional." })
      })
    }),
    portfolio_monitor: Object.freeze({
      label: "Quarterly review",
      stages: Object.freeze({
        add: Object.freeze({ label: "Add workbook", title: "Start and add workbook", description: "Load the supported quarterly monitor and keep its financial, inventory and banking cutoffs distinct." }),
        verify: Object.freeze({ label: "Confirm what matters", title: "Review exceptions", description: "Confirm extracted observations, formula classifications, covenants, reporting items and anomalies." }),
        judgment: Object.freeze({ label: "Add PM judgment", title: "Complete PM conclusion", description: "Record the PM assessment, rating rationale, conclusion and structured follow-up actions." }),
        review: Object.freeze({ label: "Review draft", title: "Review the monitor", description: "Challenge the officer-facing summary while retaining optional detailed schedules for analysis." }),
        deliver: Object.freeze({ label: "Download Word monitor", title: "Download the required Word monitor", description: "Word is required; clear the monitor gates and attestations for a review-ready version. Other files are optional." })
      })
    })
  });

  function workflowKey(value) {
    return value === "portfolio_monitor" ? "portfolio_monitor" : "credit_action";
  }

  function workflow(value) {
    return WORKFLOWS[workflowKey(value)];
  }

  function stageForView(workflowValue, view, currentStage) {
    const key = workflowKey(workflowValue);
    if (key === "portfolio_monitor" && view === "monitor") return STAGE_ORDER.includes(currentStage) ? currentStage : "add";
    const map = key === "portfolio_monitor"
      ? { brief: "review", sources: "verify", reconcile: "verify", workbench: "judgment", downside: "judgment", risks: "judgment", opus: "add", memo: "review", gate: "deliver", export: "deliver" }
      : { sources: "add", opus: "add", reconcile: "verify", workbench: "judgment", downside: "judgment", risks: "judgment", brief: "review", memo: "review", monitor: "review", gate: "deliver", export: "deliver" };
    return map[view] || (STAGE_ORDER.includes(currentStage) ? currentStage : "add");
  }

  function stageView(workflowValue, stage, model) {
    const key = workflowKey(workflowValue);
    if (key === "portfolio_monitor") {
      if (stage === "deliver") return "export";
      return "monitor";
    }
    if (stage === "add") return "sources";
    if (stage === "verify") return model && model.conflicts > 0 ? "reconcile" : "sources";
    if (stage === "judgment") return model && !model.stressCurrent ? "downside" : "workbench";
    if (stage === "review") return "brief";
    return "export";
  }

  function completionChecks(model) {
    if (workflowKey(model.workflow) === "portfolio_monitor") {
      const added = Boolean(model.monitorLoaded);
      const verified = added && Boolean(model.monitorReviewed) && model.candidates === 0 && model.conflicts === 0;
      const judged = verified && Boolean(model.monitorJudgmentComplete);
      const reviewed = judged && Boolean(model.monitorDraftReviewed);
      return [added, verified, judged, reviewed, Boolean(model.ready)];
    }
    const added = Boolean(model.workbookScopeConfirmed) && Boolean(model.workbookLoaded) && model.packetCount > 0 && Number(model.requiredDocumentOpen || 0) === 0;
    const verified = added && model.candidates === 0 && model.conflicts === 0;
    const judged = verified && Boolean(model.stressCurrent) && Boolean(model.creditJudgmentComplete);
    const reviewed = judged && model.memoIncomplete === 0 && !model.staleNarratives;
    return [added, verified, judged, reviewed, Boolean(model.ready)];
  }

  function progress(model) {
    const config = workflow(model.workflow);
    const checks = completionChecks(model);
    const firstIncomplete = checks.findIndex((value) => !value);
    return STAGE_ORDER.map((id, index) => ({
      id,
      ...config.stages[id],
      status: checks[index] ? "complete" : index === firstIncomplete ? "current" : "upcoming"
    }));
  }

  function nextAction(model) {
    if (model.landing) return null;
    if (model.mode === "demo") {
      if (model.activeView === "brief") return { id: "sample_memo", label: "Open the sample memo", action: "navigate", view: "memo", stage: "review" };
      if (model.activeView === "memo") return { id: "sample_check", label: "See the final control check", action: "navigate", view: "gate", stage: "deliver" };
      if (model.activeView === "gate") return { id: "sample_package", label: "View the sample package", action: "navigate", view: "export", stage: "deliver" };
      return { id: "sample_decision", label: "Review the sample decision", action: "navigate", view: "brief", stage: "review" };
    }
    if (workflowKey(model.workflow) === "portfolio_monitor") {
      if (!model.monitorLoaded) return { id: "monitor", label: "Add quarterly monitor", action: "trigger_monitor", stage: "add" };
      if (!model.monitorReviewed || model.candidates > 0 || model.conflicts > 0) return { id: "monitor_review", label: "Review workbook exceptions", action: "navigate", view: "monitor", stage: "verify" };
      if (!model.monitorJudgmentComplete) return { id: "monitor_judgment", label: "Complete PM conclusion", action: "navigate", view: "monitor", stage: "judgment" };
      if (!model.monitorDraftReviewed) return { id: "monitor_officer_review", label: "Review the officer draft", action: "navigate", view: "monitor", stage: "review" };
      if (model.blockers > 0 || model.failedControls > 0 || !model.attested || !model.finalized) return { id: "monitor_gate", label: model.blockers > 0 ? `Resolve ${model.blockers} review blocker${model.blockers === 1 ? "" : "s"}` : "Complete final check", action: "navigate", view: "gate", stage: "deliver" };
      return { id: "monitor_export", label: "Download required Word monitor", action: "navigate", view: "export", stage: "deliver" };
    }
    if (!model.workbookScopeConfirmed) return { id: "workbook_scope", label: "Confirm underwriting tabs", action: "navigate", view: "sources", anchor: "workbook-scope", stage: "add" };
    if (!model.workbookLoaded) return { id: "workbook", label: "Add underwriting workbook", action: "trigger_workbook", stage: "add" };
    if (model.packetCount === 0) return { id: "packet", label: "Open first Opus batch", action: "navigate", view: "opus", stage: "add" };
    if (Number(model.requiredDocumentOpen || 0) > 0) return { id: "documents", label: `Add ${model.requiredDocumentOpen} required document${model.requiredDocumentOpen === 1 ? "" : "s"}`, action: "navigate", view: "sources", stage: "add" };
    if (model.candidates > 0) return { id: "facts", label: `Review ${model.candidates} candidate fact${model.candidates === 1 ? "" : "s"}`, action: "navigate", view: "sources", stage: "verify" };
    if (model.conflicts > 0) return { id: "conflicts", label: `Resolve ${model.conflicts} conflicting value${model.conflicts === 1 ? "" : "s"}`, action: "navigate", view: "reconcile", stage: "verify" };
    if (!model.stressCurrent) return { id: "downside", label: "Record the downside case", action: "navigate", view: "downside", stage: "judgment" };
    if (!model.creditJudgmentComplete) {
      const task = model.nextJudgmentTask;
      if (task && task.view) return { id: `judgment_${task.id}`, label: `Complete ${task.label}`, action: "navigate", view: task.view, anchor: task.anchor || "", stage: "judgment" };
      return { id: "judgment", label: "Complete PM analysis", action: "navigate", view: "workbench", stage: "judgment" };
    }
    if (model.memoIncomplete > 0 || model.staleNarratives) return { id: "memo", label: model.staleNarratives ? "Refresh the affected memo" : `Complete ${model.memoIncomplete} memo section${model.memoIncomplete === 1 ? "" : "s"}`, action: "navigate", view: "memo", stage: "review" };
    if (model.blockers > 0 || model.failedControls > 0 || !model.attested || !model.finalized) return { id: "gate", label: model.blockers > 0 ? `Resolve ${model.blockers} review blocker${model.blockers === 1 ? "" : "s"}` : "Complete final check", action: "navigate", view: "gate", stage: "deliver" };
    return { id: "export", label: "Download required Word memo", action: "navigate", view: "export", stage: "deliver" };
  }

  function derive(model) {
    const stages = progress(model);
    const selectedStage = STAGE_ORDER.includes(model.activeStage) ? model.activeStage : stages.find((stage) => stage.status === "current")?.id || "deliver";
    return {
      workflow: workflow(model.workflow),
      stages,
      selectedStage,
      selected: workflow(model.workflow).stages[selectedStage],
      next: nextAction({ ...model, activeStage: selectedStage })
    };
  }

  window.HBF_Guided = Object.freeze({ STAGE_ORDER, WORKFLOWS, workflowKey, workflow, stageForView, stageView, completionChecks, progress, nextAction, derive });
})();
