(function () {
  "use strict";

  const CORE_FIELD_DEFINITIONS = Object.freeze([
    Object.freeze({ path: "borrower.legalName", label: "Borrower legal name", cutoff: "review" }),
    Object.freeze({ path: "credit.currentRiskRating", label: "Current risk rating", cutoff: "review" }),
    Object.freeze({ path: "facility.lineMaturity", label: "Line maturity", cutoff: "review" }),
    Object.freeze({ path: "facility.grossCommitment", label: "Gross commitment", cutoff: "banking" }),
    Object.freeze({ path: "relationship.outstanding", label: "Relationship outstanding", cutoff: "banking" }),
    Object.freeze({ path: "relationship.averageDeposits", label: "Relationship deposits", cutoff: "banking" }),
    Object.freeze({ path: "financial.revenueQuarter", label: "Quarterly revenue", cutoff: "financial" }),
    Object.freeze({ path: "financial.netIncomeQuarter", label: "Quarterly net income", cutoff: "financial" }),
    Object.freeze({ path: "operating.closingsQuarter", label: "Quarterly closings", cutoff: "financial" }),
    Object.freeze({ path: "financial.totalAssets", label: "Total assets", cutoff: "balance" }),
    Object.freeze({ path: "financial.totalLiabilities", label: "Total liabilities", cutoff: "balance" }),
    Object.freeze({ path: "financial.reportedTangibleNetWorth", label: "Reported tangible net worth", cutoff: "balance" }),
    Object.freeze({ path: "inventory.totalUnits", label: "Owned inventory units", cutoff: "inventory" }),
    Object.freeze({ path: "inventory.lotsOwnedControlled", label: "Owned and controlled lots", cutoff: "inventory" })
  ]);

  const PROFILE_LABELS = Object.freeze({
    executive: "Compact two-page monitor",
    standard: "Monitor + compact schedules",
    full: "Full monitor + appendices"
  });

  const clean = (value) => String(value == null ? "" : value).trim();
  const list = (value) => Array.isArray(value) ? value : [];
  const open = (item) => item && !["resolved", "superseded", "closed", "complete", "completed", "cancelled", "canceled"].includes(clean(item.status).toLowerCase());
  const accepted = (fact) => fact && ["accepted", "supported"].includes(fact.status) && fact.controlling !== false;
  const validDate = (value) => /^\d{4}-\d{2}-\d{2}$/.test(clean(value)) && Number.isFinite(Date.parse(`${clean(value)}T00:00:00Z`));

  function latest(series, cutoff) {
    return list(series).filter((item) => validDate(item?.periodEnd) && (!cutoff || item.periodEnd <= cutoff)).sort((a, b) => clean(a.periodEnd).localeCompare(clean(b.periodEnd))).slice(-1)[0] || null;
  }

  function previous(series, cutoff) {
    const rows = list(series).filter((item) => validDate(item?.periodEnd) && (!cutoff || item.periodEnd <= cutoff)).sort((a, b) => clean(a.periodEnd).localeCompare(clean(b.periodEnd)));
    return rows.length > 1 ? rows.at(-2) : null;
  }

  function dayDifference(start, end) {
    if (!validDate(start) || !validDate(end)) return null;
    return Math.round((Date.parse(`${end}T00:00:00Z`) - Date.parse(`${start}T00:00:00Z`)) / 86400000);
  }

  function formatMoney(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) return "Not provided";
    const absolute = Math.abs(number);
    if (absolute >= 1000000) return `${number < 0 ? "−" : ""}$${(absolute / 1000000).toFixed(1)}MM`;
    if (absolute >= 1000) return `${number < 0 ? "−" : ""}$${(absolute / 1000).toFixed(0)}K`;
    return `${number < 0 ? "−" : ""}$${absolute.toFixed(0)}`;
  }

  function formatChange(current, prior, kind) {
    const a = Number(current); const b = Number(prior);
    if (!Number.isFinite(a) || !Number.isFinite(b)) return "No comparable period";
    if (kind === "money") return `${formatMoney(a)} from ${formatMoney(b)} (${formatMoney(a - b)})`;
    if (kind === "percent") return `${(a * 100).toFixed(1)}% from ${(b * 100).toFixed(1)}% (${((a - b) * 100).toFixed(1)} pts)`;
    return `${a.toLocaleString("en-US")} from ${b.toLocaleString("en-US")} (${a - b >= 0 ? "+" : ""}${(a - b).toLocaleString("en-US")})`;
  }

  function targetScopes(monitor) {
    const bank = latest(monitor?.bankingSeries, monitor?.reviewAsOfDate);
    const quarter = latest(monitor?.financial?.quarterly, monitor?.financialPeriodEnd);
    const balance = latest(monitor?.balanceSheets, monitor?.financialPeriodEnd);
    const inventory = latest(monitor?.inventorySeries, monitor?.inventoryPeriodEnd);
    const cutoffs = {
      review: monitor?.reviewAsOfDate || "",
      banking: bank?.periodEnd || "",
      financial: quarter?.periodEnd || "",
      balance: balance?.periodEnd || "",
      inventory: inventory?.periodEnd || ""
    };
    const values = {
      "borrower.legalName": monitor?.identity?.borrower,
      "credit.currentRiskRating": monitor?.rating?.current,
      "facility.lineMaturity": monitor?.facility?.lineMaturity,
      "facility.grossCommitment": bank?.grossCommitment,
      "relationship.outstanding": bank?.outstanding,
      "relationship.averageDeposits": bank?.deposits,
      "financial.revenueQuarter": quarter?.revenue,
      "financial.netIncomeQuarter": quarter?.netIncome,
      "operating.closingsQuarter": quarter?.closings,
      "financial.totalAssets": balance?.totalAssets,
      "financial.totalLiabilities": balance?.totalLiabilities,
      "financial.reportedTangibleNetWorth": balance?.tangibleNetWorth,
      "inventory.totalUnits": inventory?.totalUnits,
      "inventory.lotsOwnedControlled": inventory?.lotsOwnedControlled
    };
    return CORE_FIELD_DEFINITIONS.map((definition) => ({ ...definition, asOfDate: cutoffs[definition.cutoff] || "", value: values[definition.path] }));
  }

  function valuesMatch(actual, expected) {
    if (typeof expected === "number" && Number.isFinite(expected)) return Number.isFinite(Number(actual)) && Math.abs(Number(actual) - expected) <= Math.max(1e-8, Math.abs(expected) * 1e-9);
    return clean(actual) === clean(expected);
  }

  function coreCoverage(state) {
    const monitor = state?.monitor || null;
    const targets = targetScopes(monitor);
    const sourceFacts = list(state?.facts).filter((fact) => fact?.sourceId === monitor?.workbookSourceId && fact.recordStatus !== "superseded");
    const sourceObservations = sourceFacts.length ? sourceFacts : list(monitor?.observations);
    const coreKeys = new Set(targets.map((item) => `${item.path}|${item.asOfDate}`));
    const fields = targets.map((target) => {
      const candidates = sourceFacts.filter((fact) => fact.path === target.path && fact.asOfDate === target.asOfDate);
      return { ...target, complete: candidates.some((fact) => accepted(fact) && valuesMatch(fact.value, target.value)), candidateCount: candidates.length };
    });
    const supplemental = sourceObservations.filter((fact) => !coreKeys.has(`${fact?.path || ""}|${fact?.asOfDate || ""}`));
    return {
      total: CORE_FIELD_DEFINITIONS.length,
      completeCount: fields.filter((field) => field.complete).length,
      pendingCount: fields.filter((field) => !field.complete).length,
      fields,
      sourceObservationCount: sourceObservations.length,
      supplementalCount: supplemental.length,
      supplementalIds: supplemental.map((item) => item.id).filter(Boolean)
    };
  }

  function sourceBound(state) {
    const monitor = state?.monitor;
    if (!monitor?.profileMatched || !monitor?.workbookSourceId) return false;
    if (state?.mode === "demo") return true;
    const source = list(state?.sources).find((item) => item.id === monitor.workbookSourceId && item.status !== "superseded");
    const workbook = state?.monitorWorkbook;
    return Boolean(source && workbook?.loaded && workbook.sourceId === monitor.workbookSourceId && workbook.digest && source.fingerprint === workbook.digest);
  }

  function cutoffState(monitor) {
    const bank = latest(monitor?.bankingSeries, monitor?.reviewAsOfDate);
    const review = monitor?.reviewAsOfDate || "";
    const financial = monitor?.financialPeriodEnd || "";
    const inventory = monitor?.inventoryPeriodEnd || "";
    const banking = bank?.periodEnd || "";
    const complete = [review, financial, inventory, banking].every(validDate);
    const ordered = complete && monitor?.reviewDateBasis === "user_explicit" && financial <= review && inventory <= review && banking <= review;
    return { review, financial, inventory, banking, complete, ordered };
  }

  function intakePlan(state) {
    const monitor = state?.monitor;
    const coverage = coreCoverage(state);
    const cutoffs = cutoffState(monitor);
    const observationCount = list(state?.facts).filter((fact) => fact.sourceId === monitor?.workbookSourceId && fact.recordStatus !== "superseded").length || list(monitor?.observations).length;
    return [
      { id: "profile", label: "Recognized workbook and source fingerprint", complete: sourceBound(state), owner: "Portfolio manager", detail: "Exact HBF quarterly-monitor profile and active source version." },
      { id: "review_date", label: "Explicit review date", complete: validDate(cutoffs.review) && monitor?.reviewDateBasis === "user_explicit", owner: "Portfolio manager", detail: "The computer date is never substituted." },
      { id: "cutoffs", label: "Four source cutoffs identified", complete: cutoffs.ordered, owner: "Portfolio manager", detail: "Review, financial, inventory and latest eligible banking dates remain distinct." },
      { id: "core", label: "Defined 14-field core staged", complete: targetsAvailable(monitor), owner: "Portfolio manager / analyst", detail: "Each core field is reconciled individually before it controls output." },
      { id: "observations", label: "Workbook observations staged for review", complete: observationCount > 0 || state?.mode === "demo", owner: "Portfolio manager", detail: `${observationCount} active observation${observationCount === 1 ? "" : "s"}; ${coverage.supplementalCount} supplemental.` }
    ];
  }

  function targetsAvailable(monitor) {
    if (!monitor) return false;
    const scopes = targetScopes(monitor);
    return scopes.every((scope) => validDate(scope.asOfDate) && scope.value != null && clean(scope.value));
  }

  function completeAction(action) {
    if (!action || clean(action.action).length < 20 || clean(action.owner).length < 2 || !validDate(action.dueDate) || clean(action.evidence).length < 5) return false;
    return !["cancelled", "canceled"].includes(clean(action.status).toLowerCase());
  }

  function covenantNeedsReview(item) {
    return Boolean(item && (item.comparable === false || item.outcomeMismatch || /review|required|breach|fail|exception|non.?compliant/i.test(`${item.status || ""} ${item.sourceStatus || ""} ${item.reportedOutcome || ""}`)));
  }

  function addRow(rows, row) {
    if (!row?.id || rows.some((item) => item.id === row.id)) return;
    rows.push({ owner: "Portfolio manager", dueDate: "", status: "Open", actionAnchor: "monitor-action-work", ...row });
  }

  function exceptionQueue(state, context) {
    const monitor = state?.monitor;
    if (!monitor) return [];
    const rows = [];
    const gates = list(context?.gates);
    const cutoffs = cutoffState(monitor);
    const maturityDays = Number.isFinite(Number(context?.maturityDays)) ? Number(context.maturityDays) : dayDifference(monitor.reviewAsOfDate, monitor.facility?.lineMaturity);
    const balance = latest(monitor.balanceSheets, monitor.financialPeriodEnd);
    const crossFoot = Number.isFinite(Number(context?.crossFootDifference)) ? Number(context.crossFootDifference) : Number(balance?.crossFootDifference);

    list(monitor.anomalies).filter(open).forEach((item) => addRow(rows, {
      id: `anomaly:${item.id}`, rank: item.severity === "blocker" ? 0 : 2, band: item.severity === "blocker" ? "Workbook blocker" : "Workbook diagnostic", severity: item.severity === "blocker" ? "blocker" : item.severity === "informational" || item.severity === "note" ? "note" : "warning", title: item.title || "Workbook anomaly", detail: item.detail || "Review the retained workbook diagnostic.", status: item.status || "Open", actionAnchor: "monitor-anomaly-work"
    }));

    list(state?.conflicts).filter((item) => !item.status || item.status === "open").forEach((item) => addRow(rows, {
      id: `conflict:${item.id}`, rank: 1, band: "Same-scope conflict", severity: "blocker", title: item.field || item.fieldPath || "Competing value", detail: "Select one period-matched controlling value and record the PM rationale.", actionAnchor: "monitor-core-work"
    }));

    if (!cutoffs.ordered) addRow(rows, {
      id: "cutoff:invalid", rank: 2, band: "Cutoff integrity", severity: "blocker", title: "Review or source cutoff is missing or out of order", detail: "Financial, inventory and latest banking periods must be dated on or before the explicit review date.", actionAnchor: "monitor-cutoff-work"
    });

    if (maturityDays == null || maturityDays < 365) addRow(rows, {
      id: "maturity", rank: maturityDays != null && maturityDays < 0 ? 2 : 4, band: maturityDays != null && maturityDays < 0 ? "Expired maturity" : "Near maturity", severity: maturityDays != null && maturityDays < 0 ? "blocker" : "warning", title: maturityDays == null ? "Maturity requires date reconciliation" : maturityDays < 0 ? `Facility maturity passed ${Math.abs(maturityDays)} days ago` : `${maturityDays} days remain to facility maturity`, detail: maturityDays != null && maturityDays < 0 ? "A structured repayment, renewal or extension disposition is required." : "Confirm the renewal or repayment path and carry the timing into the PM conclusion.", actionAnchor: "monitor-action-work"
    });

    list(monitor.covenants).filter(covenantNeedsReview).forEach((item) => addRow(rows, {
      id: `covenant:${item.id}`, rank: 5, band: "Covenant exception", severity: /breach|fail|non.?compliant/i.test(`${item.status || ""} ${item.sourceStatus || ""}`) ? "blocker" : "warning", title: item.name || "Covenant requires review", detail: item.comparable === false ? "Threshold and actual are not comparable; document the reviewed disposition and evidence path." : item.outcomeMismatch ? "Reported and independently computed outcomes do not agree." : `Reported status: ${item.status || item.sourceStatus || "Review required"}.`, status: item.status || "Review required", actionAnchor: "monitor-covenant-work"
    }));

    list(monitor.reportingItems).filter((item) => ["Past due", "Review required"].includes(item.status)).forEach((item) => addRow(rows, {
      id: `reporting:${item.id}`, rank: 6, band: "Reporting exception", severity: item.status === "Past due" ? "blocker" : "warning", title: item.name || "Reporting item requires review", detail: item.status === "Past due" ? `Past due as of the explicit review date; due ${item.dueDate || "date not available"}.` : "Receipt period or due-date basis requires PM review.", dueDate: item.dueDate || "", status: item.status, actionAnchor: "monitor-reporting-work"
    }));

    if (Number.isFinite(crossFoot) && Math.abs(crossFoot) >= 1) addRow(rows, {
      id: "crossfoot", rank: 7, band: "Reconciliation", severity: "blocker", title: `Balance sheet is out of balance by ${formatMoney(crossFoot)}`, detail: "Correct the workbook or record a structured cross-foot disposition with evidence.", actionAnchor: "monitor-action-work"
    });

    const currentRating = clean(monitor.rating?.current);
    const recommendedRating = clean(monitor.rating?.recommended);
    if (!recommendedRating || currentRating !== recommendedRating || clean(monitor.ratingRationale).length < 50) addRow(rows, {
      id: "rating", rank: 8, band: currentRating !== recommendedRating && recommendedRating ? "Rating movement" : "Rating judgment", severity: !recommendedRating || clean(monitor.ratingRationale).length < 50 ? "blocker" : "warning", title: !recommendedRating ? "Recommended risk rating is required" : currentRating !== recommendedRating ? `Risk rating moves ${currentRating || "not provided"} → ${recommendedRating}` : "Rating rationale requires completion", detail: clean(monitor.ratingRationale).length >= 50 ? "Credit Officer review of the PM-owned rationale is required." : "Record the PM-owned rationale and contrary evidence; the Studio never assigns a rating.", actionAnchor: "monitor-decision-work"
    });

    list(monitor.watchItems).filter(open).forEach((item) => addRow(rows, {
      id: `watch:${item.id}`, rank: 9, band: "Monitoring signal", severity: item.severity === "blocker" ? "blocker" : item.severity === "note" ? "note" : "warning", title: item.title || "Open watch item", detail: item.detail || "Carry the signal into the PM conclusion or structured follow-up.", owner: item.owner || "Portfolio manager", status: item.status || "Open", actionAnchor: "monitor-action-work"
    }));

    const requiredActionScopes = [];
    list(monitor.reportingItems).filter((item) => ["Past due", "Review required"].includes(item.status)).forEach((item) => requiredActionScopes.push({ id: `reporting-action:${item.id}`, title: item.name, match: (action) => action.reportingItemId === item.id }));
    list(monitor.covenants).filter(covenantNeedsReview).forEach((item) => requiredActionScopes.push({ id: `covenant-action:${item.id}`, title: item.name, match: (action) => action.covenantId === item.id }));
    if (Number.isFinite(crossFoot) && Math.abs(crossFoot) >= 1) requiredActionScopes.push({ id: "crossfoot-action", title: "Balance-sheet cross-foot", match: (action) => action.relatedControlId === "balance_crossfoot" });
    if (maturityDays != null && maturityDays < 0) requiredActionScopes.push({ id: "maturity-action", title: "Expired line maturity", match: (action) => action.relatedControlId === "line_maturity" });
    requiredActionScopes.filter((scope) => !list(monitor.actions).some((action) => scope.match(action) && completeAction(action))).forEach((scope) => addRow(rows, {
      id: scope.id, rank: 10, band: "Action gap", severity: "blocker", title: `${scope.title} has no complete structured action`, detail: "Add a specific action, owner, due date and evidence or verification path.", actionAnchor: "monitor-action-work"
    }));

    gates.filter((gate) => gate && gate.pass === false).forEach((gate, index) => {
      addRow(rows, { id: `gate:${index}:${clean(gate.title)}`, rank: 3, band: "Readiness control", severity: "blocker", title: gate.title || "Monitor control remains open", detail: gate.detail || "Complete the linked monitor control before delivery.", actionAnchor: "monitor-control-work" });
    });

    return rows.sort((a, b) => Number(a.rank) - Number(b.rank) || clean(a.title).localeCompare(clean(b.title)) || clean(a.id).localeCompare(clean(b.id)));
  }

  function carryForward(state, context) {
    const monitor = state?.monitor || {};
    const quarter = latest(monitor.financial?.quarterly, monitor.financialPeriodEnd);
    const priorQuarter = previous(monitor.financial?.quarterly, monitor.financialPeriodEnd);
    const ytdRows = list(monitor.financial?.ytd).filter((item) => validDate(item?.periodEnd) && item.periodEnd <= monitor.financialPeriodEnd).sort((a, b) => clean(a.periodEnd).localeCompare(clean(b.periodEnd)));
    const currentYtd = ytdRows.at(-1) || null;
    const priorYtd = ytdRows.length > 1 ? ytdRows.at(-2) : null;
    const bankRows = list(monitor.bankingSeries).filter((item) => validDate(item?.periodEnd) && item.periodEnd <= monitor.reviewAsOfDate).sort((a, b) => clean(a.periodEnd).localeCompare(clean(b.periodEnd)));
    const bank = bankRows.at(-1) || null;
    const priorBank = bankRows.length > 1 ? bankRows[0] : null;
    const queue = exceptionQueue(state, context);
    const actions = list(monitor.actions).filter(open).map((item) => ({ id: item.id, action: item.action || "Action not stated", owner: item.owner || "Unassigned", dueDate: item.dueDate || "Not dated", evidence: item.evidence || "Not supplied", status: item.status || "Open" }));
    const changes = [
      { id: "revenue", label: "YTD revenue", value: formatChange(currentYtd?.revenue, priorYtd?.revenue, "money") },
      { id: "closings", label: "YTD closings", value: formatChange(currentYtd?.closings, priorYtd?.closings, "number") },
      { id: "margin", label: "Quarterly gross margin", value: formatChange(quarter?.grossMargin, priorQuarter?.grossMargin, "percent") },
      { id: "outstanding", label: "Relationship outstanding", value: formatChange(bank?.outstanding, priorBank?.outstanding, "money") }
    ];
    const current = clean(monitor.rating?.current) || "Not provided";
    const recommended = clean(monitor.rating?.recommended) || "PM selection required";
    return {
      changes,
      actions,
      exceptionCount: queue.length,
      materialExceptionCount: queue.filter((item) => item.severity !== "note").length,
      nextExceptions: queue.filter((item) => item.severity !== "note").slice(0, 5),
      pmConclusion: clean(monitor.conclusion) || "Portfolio manager conclusion required.",
      assessment: clean(monitor.assessment) || "PM assessment required",
      rating: { current, recommended, moved: current !== recommended },
      ratingRationale: clean(monitor.ratingRationale) || "Portfolio manager rating rationale required."
    };
  }

  function outputProfile(monitor) {
    const key = Object.prototype.hasOwnProperty.call(PROFILE_LABELS, monitor?.outputProfile) ? monitor.outputProfile : "executive";
    const includeFinancial = key === "standard" || key === "full" || Boolean(monitor?.includeFinancialTables);
    const includeBalance = key === "standard" || key === "full" || Boolean(monitor?.includeBalanceSheetTable);
    const includeLedger = key === "full";
    const included = ["Two-page executive core", ...(includeFinancial ? [key === "standard" ? "Compact financial-statement schedule" : "Financial-statement schedule"] : []), ...(includeBalance ? [key === "standard" ? "Compact balance-sheet schedule" : "Balance-sheet schedule"] : []), ...(includeLedger ? ["Profile-bound observation ledger"] : [])];
    const omitted = [!includeFinancial ? "Financial-statement schedule" : "", !includeBalance ? "Balance-sheet schedule" : "", !includeLedger ? "Profile-bound observation ledger" : ""].filter(Boolean);
    return { key, label: PROFILE_LABELS[key], included, omitted, includeFinancial, includeBalance, includeLedger, analysisRetained: true };
  }

  function judgmentComplete(monitor) {
    return Boolean(clean(monitor?.assessment).length >= 12 && clean(monitor?.rating?.recommended) && clean(monitor?.ratingRationale).length >= 50 && clean(monitor?.conclusion).length >= 80);
  }

  function stageSummary(stage, state, model, context) {
    const monitor = state?.monitor;
    const coverage = coreCoverage(state);
    const queue = exceptionQueue(state, context);
    let checks = [];
    let owner = "Portfolio manager";
    if (stage === "add") {
      checks = intakePlan(state).map((item) => ({ label: item.label, complete: item.complete }));
      owner = "Portfolio manager / analyst";
    } else if (stage === "verify") {
      const blockingAnomalies = list(monitor?.anomalies).filter((item) => open(item) && item.severity === "blocker");
      checks = [
        { label: "Review and source cutoffs confirmed", complete: cutoffState(monitor).ordered },
        { label: `Defined core individually reconciled (${coverage.completeCount}/14)`, complete: coverage.completeCount === coverage.total },
        { label: "Supplemental observations reviewed by exception", complete: Boolean(monitor?.reviewed) },
        { label: "Formula and workbook blockers dispositioned", complete: blockingAnomalies.length === 0 && Boolean(monitor?.anomalyDispositionReviewed) },
        { label: "Reporting and covenant exceptions reviewed", complete: Boolean(monitor?.reportingReviewed) && Boolean(monitor?.covenantReviewConfirmed) },
        { label: "Same-scope conflicts resolved", complete: Number(model?.conflicts || 0) === 0 }
      ];
    } else if (stage === "judgment") {
      checks = [
        { label: "Overall monitoring assessment", complete: clean(monitor?.assessment).length >= 12 },
        { label: "PM-selected recommended rating", complete: Boolean(clean(monitor?.rating?.recommended)) },
        { label: "Rating rationale and contrary evidence", complete: clean(monitor?.ratingRationale).length >= 50 },
        { label: "PM conclusion and carry-forward", complete: clean(monitor?.conclusion).length >= 80 },
        { label: "Structured follow-up actions", complete: !queue.some((item) => item.band === "Action gap") }
      ];
    } else if (stage === "review") {
      const profile = outputProfile(monitor);
      checks = [
        { label: "Officer carry-forward summary assembled", complete: judgmentComplete(monitor) },
        { label: "All exceptions remain visible", complete: Boolean(monitor) },
        { label: "Current and recommended rating shown", complete: Boolean(clean(monitor?.rating?.current) && clean(monitor?.rating?.recommended)) },
        { label: `Officer output profile: ${profile.label}`, complete: Boolean(monitor?.outputProfile) },
        { label: "Detailed financial and balance analysis retained", complete: profile.analysisRetained },
        { label: "PM review of officer-facing draft", complete: Boolean(model?.monitorDraftReviewed) }
      ];
      owner = "Portfolio manager → Credit Officer";
    } else {
      const attested = Object.values(state?.attestations || {}).filter(Boolean).length;
      checks = [
        { label: "All monitor readiness controls pass", complete: Number(model?.failedControls || 0) === 0 && Number(model?.blockers || 0) === 0 },
        { label: `Current-revision PM attestations (${attested}/4)`, complete: attested === 4 },
        { label: "Package marked Review Package Complete", complete: Boolean(model?.ready) }
      ];
    }
    return {
      stage,
      owner,
      completeCount: checks.filter((check) => check.complete).length,
      totalCount: checks.length,
      complete: checks.filter((check) => check.complete).map((check) => check.label),
      remaining: checks.filter((check) => !check.complete).map((check) => check.label)
    };
  }

  window.HBF_MonitorPath = Object.freeze({
    CORE_FIELD_DEFINITIONS,
    PROFILE_LABELS,
    targetScopes,
    coreCoverage,
    cutoffState,
    intakePlan,
    exceptionQueue,
    carryForward,
    outputProfile,
    stageSummary
  });
})();
