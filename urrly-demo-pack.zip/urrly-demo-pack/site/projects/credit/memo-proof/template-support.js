(function(g){
  'use strict';
  const K=g.HBFTemplate,D=K.D;
  // Fixed source locations, not inferred page numbers or editable heading text.
  const sections=[
    ['borrowing',982,1002,1063],['sales',983,1063,1126],['financial',984,1126,1317],
    ['project',985,1317,1380],['market',986,1380,1443],['construction',989,1443,1506],
    ['guarantor',990,1506,1549],['definitions',991,1551,1614],['profitability',992,1614,1677],
    ['references',993,1677,1740],['cra',994,1740,1803],['rating',995,1803,1866],
    ['other',996,1866,1957],['diligence',997,1957,2154],['spreads',998,2154,2159]
  ].map(([id,list,heading,end])=>({id,list:'p'+list,heading:'p'+heading,endId:'p'+end,
    label:D.paragraphs['p'+list].value.trim(),start:D.paragraphs['p'+heading].start,end:D.paragraphs['p'+end].start}));
  const included=(s,id)=>s.sectionChoices?.[id]!==false;
  const containing=key=>{const r=D.paragraphs[key]||D.controls[key]||D.tables[key]||D.rows[key];return r&&sections.find(x=>r.start>=x.start&&r.end<=x.end);};
  const excludedRanges=s=>sections.filter(x=>!included(s,x.id));
  function flow(s){
    const active=excludedRanges(s).length||s.inserts.some(x=>containing(x.anchor)||x.anchor==='p1549')||Object.keys(s.values).some(k=>containing(k));
    if(!active)return {spacers:[],headings:[]};
    const spacers=[],anchors=new Set(s.inserts.map(x=>x.anchor));
    for(const section of sections.filter(x=>included(s,x.id))){let run=[];const flush=()=>{spacers.push(...run.slice(2));run=[];};
      for(const p of Object.values(D.paragraphs).filter(p=>p.start>=section.start&&p.end<=section.end).sort((a,b)=>a.start-b.start)){
        if(p.simple&&!p.table&&!p.value.trim()&&!Object.hasOwn(s.values,p.id)&&!anchors.has(p.id)&&!/<w:(?:br\b|bookmark|comment|drawing|sectPr)/.test(D.xml.slice(p.start,p.end))){if(run.length&&run.at(-1).end!==p.start)flush();run.push(p);}else flush();
      }flush();
    }
    // The reference uses blank paragraphs to fill pages. Native page starts
    // preserve its section flow when populated content replaces that space.
    const headings=[...sections.filter(x=>included(s,x.id)).map(x=>x.heading),'p1549',...(included(s,'financial')?['p1190']:[])].sort((a,b)=>D.paragraphs[a].start-D.paragraphs[b].start).slice(1);
    return {spacers,headings};
  }
  function setSection(s,id,value){
    if(!sections.some(x=>x.id===id)||typeof value!=='boolean')throw new Error('Choose a supporting section.');
    if(included(s,id)===value)return;
    s.sectionChoices={...s.sectionChoices};if(value)delete s.sectionChoices[id];else s.sectionChoices[id]=false;
    if(!Object.keys(s.sectionChoices).length)delete s.sectionChoices;K.changed(s);
  }
  function visible(s,key){const section=containing(key),r=D.paragraphs[key]||D.tables[key];return (!section||included(s,section.id))&&(!r||!s.hiddenRows.some(id=>D.rows[id]&&D.rows[id].start<=r.start&&D.rows[id].end>=r.end));}
  function location(s,key){
    if(!D.fields[key]||!D.paragraphs[key]?.simple||Object.values(D.boxes).some(b=>b.paragraphs.includes(key)))throw new Error('Choose a regular paragraph for this exhibit.');
    if(!visible(s,key))throw new Error('Include this section or restore its row before adding an exhibit.');return key;
  }
  function staged(s,fn){const next=K.clone(s);fn(next);K.validate(next);Object.assign(s,next);K.changed(s);return s;}
  function exhibit(s,id){const x=s.inserts.find(x=>x.id===id);if(!x)throw new Error('Choose an existing exhibit.');location(s,x.anchor);return x;}
  function setNote(s,id,key,value){if(!['narrative','source'].includes(key))throw new Error('Choose an exhibit note.');return staged(s,next=>{exhibit(next,id)[key]=value;});}
  function setCell(s,id,row,column,value){return staged(s,next=>{const x=exhibit(next,id);if(x.type!=='table')throw new Error('Choose a table cell.');const cells=row==='h'?x.value.headers:x.value.rows[row];if(!cells||!Number.isInteger(column)||column<0||column>=cells.length)throw new Error('Choose a table cell.');cells[column]=value;});}
  function pasteCells(s,id,row,column,text){
    const grid=K.parseTable(text);return staged(s,next=>{const x=exhibit(next,id);if(x.type!=='table')throw new Error('Choose a table cell.');
      const rows=[x.value.headers,...x.value.rows],start=row==='h'?0:Number(row)+1;
      if(!Number.isInteger(start)||start<0||!Number.isInteger(column)||column<0||start+grid.length>rows.length||column+grid[0].length>x.value.headers.length)throw new Error('This range is larger than the selected table. Add rows or columns, or insert it as a new table.');
      grid.forEach((values,y)=>values.forEach((v,x)=>{rows[start+y][column+x]=v;}));
    });
  }
  function tableChange(s,id,command,cell){return staged(s,next=>{const x=exhibit(next,id);if(x.type!=='table')throw new Error('Choose a table.');const t=x.value;
    if(command==='add-row'){const after=cell?.row==='h'?-1:Number.isInteger(cell?.row)?cell.row:t.rows.length-1;t.rows.splice(after+1,0,t.headers.map(()=>''));}
    else if(command==='add-column'){const after=Number.isInteger(cell?.column)?cell.column:t.headers.length-1;t.headers.splice(after+1,0,'');t.rows.forEach(r=>r.splice(after+1,0,''));}
    else if(command==='remove-row'){if(!cell||!Number.isInteger(cell.row)||!t.rows[cell.row])throw new Error('Click a data cell in the row to remove.');t.rows.splice(cell.row,1);}
    else if(command==='remove-column'){if(!cell||!Number.isInteger(cell.column)||cell.column<0||cell.column>=t.headers.length)throw new Error('Click a cell in the column to remove.');if(t.headers.length===1)throw new Error('Keep one column, or remove the whole table.');t.headers.splice(cell.column,1);t.rows.forEach(r=>r.splice(cell.column,1));}
    else throw new Error('Choose a table action.');
  });}
  function addTable(s,anchor,text,headings=true){location(s,anchor);const rows=K.parseTable(text),headers=headings?rows.shift():rows[0].map(()=>''),x={id:K.uid(),anchor,type:'table',value:{headers,rows},narrative:'',source:''};staged(s,next=>next.inserts.push(x));return x;}
  function replaceCreditReport(s,id){return staged(s,next=>{const x=exhibit(next,id);if(x.anchor!=='p1549')throw new Error('Use the Credit Report Analysis replacement control.');next.inserts=next.inserts.filter(v=>v.replaceSource!=='p1550'||v.id===id);x.replaceSource='p1550';});}
  function move(s,id,direction){return staged(s,next=>{const x=exhibit(next,id),peers=next.inserts.filter(v=>v.anchor===x.anchor),i=peers.indexOf(x),target=peers[i+direction];if(![-1,1].includes(direction)||!target)throw new Error('This exhibit is already at the end of this group.');const a=next.inserts.indexOf(x),b=next.inserts.indexOf(target);[next.inserts[a],next.inserts[b]]=[next.inserts[b],next.inserts[a]];});}
  g.HBFSupport={sections,included,containing,excludedRanges,flow,setSection,visible,location,setNote,setCell,pasteCells,tableChange,addTable,replaceCreditReport,move};
})(globalThis);
