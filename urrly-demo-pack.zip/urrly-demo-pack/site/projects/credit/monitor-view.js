(function () {
  "use strict";

  const list = (value) => Array.isArray(value) ? value : [];

  function render(options) {
    const state = options?.state || {};
    const stage = ["add", "verify", "judgment", "review"].includes(options?.stage) ? options.stage : "review";
    const gates = list(options?.gates);
    const h = options?.helpers || {};
    const esc = h.esc || ((value) => String(value == null ? "" : value));
    const formatDate = h.formatDate || ((value) => value || "Not stated");
    const monitorValue = h.monitorValue || ((value) => value == null ? "Not provided" : String(value));
    const monitorChange = h.monitorChange || (() => ({ display: "Not comparable", className: "neutral", direction: "—" }));
    const pageHead = h.pageHead || ((eyebrow, title, description, actions) => `<header class="page-head"><div><p class="eyebrow">${esc(eyebrow)}</p><h2>${esc(title)}</h2><p>${esc(description)}</p></div><div class="page-head-actions">${actions || ""}</div></header>`);
    const lineChart = h.lineChart || (() => "");
    const covenantStatusClass = h.covenantStatusClass || (() => "neutral");
    const covenantRequiresReview = h.covenantRequiresReview || (() => false);
    const monitorActionIsTerminal = h.monitorActionIsTerminal || (() => false);
    const monitorActionIsCancelled = h.monitorActionIsCancelled || (() => false);
    const monitor = state.monitor;
    const path = window.HBF_MonitorPath;

    if (!monitor) {
      const intake = path?.intakePlan(state) || [];
      return `${pageHead("Quarterly monitor intake", "Start with one supported workbook", "Enter the explicit review date in session setup, then load the approved quarterly monitor or resume a validated checkpoint.", '<button class="button button-primary" type="button" data-trigger-monitor>Load quarterly monitor</button>')}
        <section class="monitor-intake-shell">
          <div class="monitor-intake-lead"><span class="monitor-intake-mark" aria-hidden="true">Q</span><div><p class="eyebrow">Review-by-exception</p><h3>One workbook in. One officer-ready review out.</h3><p>The Studio keeps review, financial, inventory and banking dates distinct; reconciles the defined core; retains formula diagnostics; and never assigns a risk rating.</p></div></div>
          <div class="monitor-intake-grid">${intake.map((item, index) => `<article class="monitor-intake-item ${item.complete ? "is-complete" : "is-open"}"><span>${item.complete ? "✓" : index + 1}</span><div><strong>${esc(item.label)}</strong><p>${esc(item.detail)}</p><small>${esc(item.owner)}</small></div></article>`).join("")}</div>
          <div class="monitor-intake-actions"><div><strong>Local pilot boundary</strong><span>In-memory only · no application deal store · working data stays local</span></div><div><button class="button button-quiet" type="button" data-trigger-checkpoint>Resume checkpoint</button><button class="button button-primary" type="button" data-trigger-monitor>Choose workbook</button></div></div>
        </section>
        <p class="muted mt-15">Supported family: HBF quarterly portfolio monitor v2.1. Use sanitized or synthetic information until required bank approvals are complete.</p>`;
    }

    const atOrBefore = (series, cutoff) => list(series).filter((item) => item?.periodEnd && (!cutoff || item.periodEnd <= cutoff)).sort((a, b) => String(a.periodEnd).localeCompare(String(b.periodEnd)));
    const quarterly = atOrBefore(monitor.financial?.quarterly, monitor.financialPeriodEnd);
    const ytd = atOrBefore(monitor.financial?.ytd, monitor.financialPeriodEnd);
    const ttm = atOrBefore(monitor.financial?.ttm, monitor.financialPeriodEnd);
    const balances = atOrBefore(monitor.balanceSheets, monitor.financialPeriodEnd);
    const inventory = atOrBefore(monitor.inventorySeries, monitor.inventoryPeriodEnd);
    const banking = atOrBefore(monitor.bankingSeries, monitor.reviewAsOfDate);
    const latestQuarter = quarterly.at(-1) || null;
    const priorQuarter = quarterly.at(-2) || null;
    const currentYtd = ytd.at(-1) || null;
    const priorYtd = ytd.at(-2) || null;
    const latestTtm = ttm.at(-1) || null;
    const latestBalance = balances.at(-1) || null;
    const priorBalance = balances.at(-2) || null;
    const latestInventory = inventory.at(-1) || null;
    const latestBanking = banking.at(-1) || null;
    const priorBanking = banking[0] || null;
    const revenueDelta = monitorChange(currentYtd?.revenue, priorYtd?.revenue, "money");
    const closingsDelta = monitorChange(currentYtd?.closings, priorYtd?.closings, "number");
    const marginDelta = monitorChange(latestQuarter?.grossMargin, priorQuarter?.grossMargin, "percent");
    const outstandingDelta = monitorChange(latestBanking?.outstanding, priorBanking?.outstanding, "money");
    const openWatch = list(monitor.watchItems).filter((item) => item.status !== "resolved");
    const pastDue = list(monitor.reportingItems).filter((item) => item.status === "Past due");
    const covenantExceptions = list(monitor.covenants).filter(covenantRequiresReview);
    const unresolvedAnomalies = list(monitor.anomalies).filter((item) => item.status !== "resolved");
    const monitoringReady = gates.length > 0 && gates.every((gate) => gate.pass);
    const coverage = path.coreCoverage(state);
    const cutoffs = path.cutoffState(monitor);
    const exceptions = path.exceptionQueue(state, {
      gates,
      maturityDays: options?.maturityDays,
      crossFootDifference: latestBalance?.crossFootDifference
    });
    const carry = path.carryForward(state, {
      gates,
      maturityDays: options?.maturityDays,
      crossFootDifference: latestBalance?.crossFootDifference
    });
    const profile = path.outputProfile(monitor);
    const intake = path.intakePlan(state);

    const metricRows = [
      ["YTD revenue", monitorValue(currentYtd?.revenue, "money"), monitorValue(priorYtd?.revenue, "money"), revenueDelta],
      ["YTD closings", monitorValue(currentYtd?.closings, "number", 0), monitorValue(priorYtd?.closings, "number", 0), closingsDelta],
      ["Quarterly gross margin", monitorValue(latestQuarter?.grossMargin, "percent"), monitorValue(priorQuarter?.grossMargin, "percent"), marginDelta],
      ["TTM net income", monitorValue(latestTtm?.netIncome, "money"), "TTM", { display: monitorValue(latestTtm?.netMargin, "percent"), className: "neutral", direction: "" }],
      ["Facility outstanding", monitorValue(latestBanking?.outstanding, "money"), monitorValue(priorBanking?.outstanding, "money"), outstandingDelta],
      ["Facility utilization", monitorValue(latestBanking?.utilization, "percent"), monitorValue(priorBanking?.utilization, "percent"), monitorChange(latestBanking?.utilization, priorBanking?.utilization, "utilization")],
      ["Tangible net worth", monitorValue(latestBalance?.tangibleNetWorth, "money"), monitorValue(priorBalance?.tangibleNetWorth, "money"), monitorChange(latestBalance?.tangibleNetWorth, priorBalance?.tangibleNetWorth, "money")],
      ["Lot supply", monitorValue(list(monitor.calculations).find((item) => item.id === "MON-LOT-001")?.result ?? latestInventory?.lotMonthsSupply, "months"), "TTM closing pace", { display: latestInventory?.dataGranularity === "quarterly_allocated_monthly" ? "Quarterly allocation" : "Current", className: latestInventory?.lotMonthsSupply > 60 ? "warning" : "neutral", direction: "" }]
    ];

    function hero() {
      return `<section class="monitor-hero ${monitoringReady ? "is-ready" : "is-watch"}">
        <div class="monitor-assessment"><small>PM monitoring assessment</small><strong>${esc(monitor.assessment || "PM review required")}</strong><span>${esc(monitor.conclusion || "Portfolio manager conclusion required.")}</span></div>
        <div class="monitor-stat"><small>Current / recommended RR</small><strong>${esc(monitor.rating?.current || state.deal?.currentRating || "Not provided")}</strong><span>${esc(monitor.rating?.recommended || state.deal?.proposedRating || "PM selection required")} recommended</span></div>
        <div class="monitor-stat"><small>Outstanding / utilization</small><strong>${esc(monitorValue(latestBanking?.outstanding, "money"))}</strong><span>${esc(monitorValue(latestBanking?.utilization, "percent"))} at ${esc(formatDate(latestBanking?.periodEnd))}</span></div>
        <div class="monitor-stat"><small>Deposits / UPB</small><strong>${esc(monitorValue(latestBanking?.deposits, "money"))}</strong><span>${esc(monitorValue(latestBanking?.depositCoverage, "percent"))} coverage</span></div>
        <div class="monitor-stat"><small>Review status</small><strong>${monitoringReady ? "Controls complete" : `${gates.filter((item) => !item.pass).length} controls open`}</strong><span>${openWatch.length} watch items · ${pastDue.length} past due</span></div>
      </section>`;
    }

    function cutoffStrip() {
      return `<section class="date-integrity" id="monitor-cutoff-work" aria-label="Reporting cutoffs">
        <div><small>Explicit review date</small><strong>${esc(formatDate(cutoffs.review))}</strong><span>Computer date is never used</span></div>
        <div><small>Financial cutoff</small><strong>${esc(formatDate(cutoffs.financial))}</strong><span>${cutoffs.financial === monitor.reportingPeriodEnd ? "Aligned to review period" : "Distinct workbook date"}</span></div>
        <div><small>Inventory cutoff</small><strong>${esc(formatDate(cutoffs.inventory))}</strong><span>${cutoffs.inventory === cutoffs.financial ? "Aligned to financials" : "Distinct source date"}</span></div>
        <div><small>Banking cutoff</small><strong>${esc(formatDate(cutoffs.banking))}</strong><span>Latest populated ≤ review date</span></div>
      </section>`;
    }

    function coveragePanel() {
      return `<section class="panel mt-15" id="monitor-core-work"><div class="panel-head"><div><p class="eyebrow">Evidence control</p><h3>Defined 14-field core</h3><p>Each core value must control at the exact entity, period and cutoff. Other workbook values remain supplemental observations.</p></div><span class="tag ${coverage.completeCount === 14 ? "good" : "warning"}">${coverage.completeCount}/14 reconciled</span></div>
        <div class="monitor-core-grid">${coverage.fields.map((field, index) => `<article class="monitor-core-field ${field.complete ? "is-complete" : "is-open"}"><span>${field.complete ? "✓" : index + 1}</span><div><strong>${esc(field.label)}</strong><small>${esc(field.path)} · ${esc(formatDate(field.asOfDate))}</small></div><em>${field.complete ? "Controlling" : field.candidateCount ? "Review" : "Missing"}</em></article>`).join("")}</div>
        <div class="monitor-supplemental"><div><strong>${coverage.supplementalCount} supplemental workbook observation${coverage.supplementalCount === 1 ? "" : "s"}</strong><span>Retained in the frozen snapshot and reviewed by exception; not represented as part of the individually controlled 14-field core.</span></div><span class="tag neutral">Clearly labeled supplemental</span></div>
      </section>`;
    }

    function exceptionPanel(includeNotes) {
      const rows = includeNotes ? exceptions : exceptions.filter((item) => item.severity !== "note");
      return `<section class="panel monitor-exceptions mt-15" id="monitor-exception-work"><div class="panel-head"><div><p class="eyebrow">Review by exception</p><h3>Priority review queue</h3><p>Workbook blockers, conflicts, cutoff defects and required actions appear before monitoring signals.</p></div><span class="tag ${rows.some((item) => item.severity === "blocker") ? "bad" : rows.length ? "warning" : "good"}">${rows.length ? `${rows.length} open` : "No open exceptions"}</span></div>
        <div class="monitor-exception-list">${rows.length ? rows.map((item, index) => `<article class="monitor-exception-row"><span class="monitor-priority">${String(index + 1).padStart(2, "0")}</span><span class="severity ${esc(item.severity)}">${esc(item.severity)}</span><div><small>${esc(item.band)}</small><strong>${esc(item.title)}</strong><p>${esc(item.detail)}</p><span>${esc(item.owner)}${item.dueDate ? ` · due ${esc(formatDate(item.dueDate))}` : ""} · ${esc(item.status)}</span></div></article>`).join("") : '<div class="monitor-clear"><strong>No exceptions require action.</strong><span>Clean results still remain available in the detailed schedules and readiness controls.</span></div>'}</div>
      </section>`;
    }

    function metricsPanel() {
      return `<section class="panel monitor-metrics"><div class="panel-head"><div><p class="eyebrow">Performance signals</p><h3>Current, comparable and directional change</h3></div><span class="tag info">No automated rating</span></div><div class="table-wrap"><table class="data-table monitor-table"><caption>Quarterly monitoring metrics</caption><thead><tr><th>Metric</th><th>Current</th><th>Comparable</th><th>Change / interpretation</th></tr></thead><tbody>${metricRows.map(([label, current, prior, delta]) => `<tr><td><strong>${esc(label)}</strong></td><td>${esc(current)}</td><td>${esc(prior)}</td><td><span class="metric-signal ${esc(delta.className)}">${esc(delta.direction)} ${esc(delta.display)}</span></td></tr>`).join("")}</tbody></table></div></section>`;
    }

    function chartsPanel() {
      return `<div class="monitor-chart-grid">
        <section class="panel"><div class="panel-head"><h3>Sales and closings</h3><span class="tag neutral">${esc(latestInventory?.dataGranularity === "quarterly_allocated_monthly" ? "Quarterly allocations" : "Dated series")}</span></div><div class="panel-body">${lineChart(inventory, [{ key: "netSales", label: "Net sales" }, { key: "closings", label: "Closings" }], "Net sales and closings trend")}</div></section>
        <section class="panel"><div class="panel-head"><h3>Inventory and backlog</h3><span class="tag ${latestInventory?.lotMonthsSupply > 60 ? "warning" : "neutral"}">${esc(monitorValue(latestInventory?.lotMonthsSupply, "months"))} lot supply</span></div><div class="panel-body">${lineChart(inventory, [{ key: "totalUnits", label: "Total units" }, { key: "backlog", label: "Backlog" }, { key: "specUnderConstruction", label: "Spec U/C" }], "Inventory composition trend")}</div></section>
        <section class="panel"><div class="panel-head"><h3>Banking relationship</h3><span class="tag info">${esc(outstandingDelta.direction)} ${esc(outstandingDelta.display)} UPB</span></div><div class="panel-body">${lineChart(banking, [{ key: "outstanding", label: "Outstanding" }, { key: "deposits", label: "Deposits" }], "Outstanding and deposit trend")}</div></section>
      </div>`;
    }

    function covenantsAndReporting() {
      return `<div class="monitor-grid" id="monitor-covenant-work">
        <section class="panel span-2"><div class="panel-head"><div><p class="eyebrow">Covenant protection</p><h3>Actual, requirement and normalized headroom</h3></div><span class="tag ${covenantExceptions.length ? "warning" : "good"}">${covenantExceptions.length ? `${covenantExceptions.length} exception / review` : "Reported compliant"}</span></div><div class="table-wrap"><table class="data-table"><caption>Current covenant tests</caption><thead><tr><th>Covenant</th><th>Requirement</th><th>Actual</th><th>Headroom</th><th>Status</th><th>Source</th></tr></thead><tbody>${list(monitor.covenants).map((item) => `<tr><td><strong>${esc(item.name)}</strong><br><span class="muted">${esc(item.entity || "Borrower")} · ${esc(formatDate(item.testDate))}</span></td><td>${esc(item.direction === "minimum" ? "Minimum " : item.direction === "maximum" ? "Maximum " : "Review ")}${esc(monitorValue(item.threshold, item.valueType === "number" ? "number" : item.valueType))}</td><td>${esc(monitorValue(item.actual, item.valueType === "number" ? "number" : item.valueType))}</td><td>${esc(item.comparable === false ? "Not comparable" : monitorValue(item.headroom, item.valueType === "number" ? "number" : item.valueType))}${item.relativeHeadroom != null ? `<br><span class="muted">${esc(monitorValue(item.relativeHeadroom, "percent"))} of threshold</span>` : ""}</td><td><span class="tag ${covenantStatusClass(item.status)}">${esc(item.status)}</span></td><td><span class="muted">${esc(item.locator || "Not provided")}</span></td></tr>`).join("") || '<tr><td colspan="6">No covenant tests were provided.</td></tr>'}</tbody></table></div></section>
        <section class="panel" id="monitor-reporting-work"><div class="panel-head"><div><p class="eyebrow">Information covenant</p><h3>Reporting status</h3></div><span class="tag ${pastDue.length ? "bad" : "good"}">${pastDue.length ? `${pastDue.length} past due` : "Current at review date"}</span></div><div class="panel-body"><div class="reporting-list">${list(monitor.reportingItems).map((item) => `<div><span><strong>${esc(item.name)}</strong><small>Last period ${esc(formatDate(item.lastReceivedPeriodEnd))} · due ${esc(formatDate(item.dueDate))}</small></span><span class="tag ${item.status === "Past due" ? "bad" : item.status === "Due soon" || item.status === "Review required" ? "warning" : "good"}">${esc(item.status)}</span></div>`).join("") || "No reporting schedule was provided."}</div></div></section>
      </div>`;
    }

    function actionsPanel() {
      const openActions = list(monitor.actions).filter((item) => !monitorActionIsTerminal(item));
      return `<section class="panel" id="monitor-action-work"><div class="panel-head"><div><p class="eyebrow">Structured follow-up</p><h3>Reporting, covenant and monitoring actions</h3></div><span class="tag ${openActions.length ? "warning" : "good"}">${openActions.length} open action${openActions.length === 1 ? "" : "s"}</span></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Reporting item / scope</th><th>Action</th><th>Owner</th><th>Due</th><th>Evidence</th><th>Status</th></tr></thead><tbody>${list(monitor.actions).map((item) => `<tr><td>${esc(list(monitor.reportingItems).find((report) => report.id === item.reportingItemId)?.name || list(monitor.covenants).find((covenant) => covenant.id === item.covenantId)?.name || (item.relatedControlId === "balance_crossfoot" ? "Balance-sheet cross-foot" : item.relatedControlId === "line_maturity" ? "Line maturity" : "General monitoring"))}</td><td>${esc(item.action || "Not stated")}</td><td>${esc(item.owner || "Unassigned")}</td><td>${esc(formatDate(item.dueDate))}</td><td>${esc(item.evidence || "Not supplied")}</td><td><span class="tag ${monitorActionIsTerminal(item) && !monitorActionIsCancelled(item) ? "good" : "warning"}">${esc(item.status || "Open")}</span>${!monitorActionIsTerminal(item) ? ` <button class="text-button" type="button" data-complete-monitor-action="${esc(item.id)}">Mark complete</button>` : ""}</td></tr>`).join("") || '<tr><td colspan="6">No structured monitoring actions recorded.</td></tr>'}</tbody></table></div>
        <form id="monitor-action-form" class="form-grid panel-body" autocomplete="off" spellcheck="false"><label class="field">Reporting item / scope<select name="reportingItemId"><option value="">General monitoring action</option><option value="CONTROL:balance_crossfoot">Balance-sheet cross-foot disposition</option><option value="CONTROL:line_maturity">Line-maturity disposition</option>${list(monitor.reportingItems).map((item) => `<option value="${esc(item.id)}">Reporting: ${esc(item.name)} — ${esc(item.status)}</option>`).join("")}${list(monitor.covenants).filter(covenantRequiresReview).map((item) => `<option value="COV:${esc(item.id)}">Covenant: ${esc(item.name)} — ${esc(item.sourceStatus || item.status)}</option>`).join("")}</select></label><label class="field">Owner<input name="owner" required maxlength="100" spellcheck="false" autocomplete="off" value="Portfolio Manager"></label><label class="field field-wide">Action<input name="action" required minlength="20" maxlength="1000" spellcheck="false" autocomplete="off" placeholder="Specific follow-up, escalation or cure"></label><label class="field">Due date<input name="dueDate" type="date" required></label><label class="field">Evidence / verification<input name="evidence" required minlength="5" maxlength="300" spellcheck="false" autocomplete="off" placeholder="Receipt, ticket, source or approval"></label><div class="field-wide right"><button class="button button-primary" type="submit">Add monitoring action</button></div></form>
      </section>`;
    }

    function anomaliesPanel() {
      return `<section class="panel" id="monitor-anomaly-work"><div class="panel-head"><div><p class="eyebrow">Workbook integrity</p><h3>Visible anomalies and excluded legacy logic</h3></div><span class="tag ${unresolvedAnomalies.some((item) => item.severity === "blocker") ? "bad" : unresolvedAnomalies.length ? "warning" : "good"}">${unresolvedAnomalies.length} open</span></div><div class="anomaly-grid">${list(monitor.anomalies).map((item) => `<article><span class="severity ${esc(item.severity === "informational" ? "note" : item.severity)}">${esc(item.severity)}</span><strong>${esc(item.title)}</strong><p>${esc(item.detail)}</p><small>${esc(item.locator || "Workbook diagnostic")} · ${esc(item.status || "Open")}</small></article>`).join("") || "<p>No workbook anomalies recorded.</p>"}</div></section>`;
    }

    function carryForwardPanel() {
      return `<section class="monitor-carry" aria-label="Quarterly carry-forward summary"><div class="monitor-carry-head"><div><p class="eyebrow">Carry-forward summary</p><h3>What changed, what needs action, what the PM concluded</h3></div><span class="tag ${carry.materialExceptionCount ? "warning" : "good"}">${carry.materialExceptionCount} material exception${carry.materialExceptionCount === 1 ? "" : "s"}</span></div><div class="monitor-carry-grid"><article><small>What changed</small>${carry.changes.map((item) => `<div><span>${esc(item.label)}</span><strong>${esc(item.value)}</strong></div>`).join("")}</article><article><small>What requires action</small>${carry.actions.length ? carry.actions.slice(0, 5).map((item) => `<div><span>${esc(item.owner)} · ${esc(formatDate(item.dueDate))}</span><strong>${esc(item.action)}</strong></div>`).join("") : '<p>No structured follow-up action is recorded.</p>'}</article><article><small>PM conclusion</small><strong class="monitor-assessment-text">${esc(carry.assessment)}</strong><p>${esc(carry.pmConclusion)}</p><span class="monitor-rating-line">Rating ${esc(carry.rating.current)} → ${esc(carry.rating.recommended)}</span></article></div></section>`;
    }

    function decisionForm() {
      return `<section class="panel" id="monitor-decision-work"><div class="panel-head"><div><p class="eyebrow">PM ownership</p><h3>Monitoring conclusion and officer-output profile</h3></div><span class="tag neutral">Underlying analysis is always retained</span></div><form id="monitor-decision-form" class="form-grid panel-body" autocomplete="off" spellcheck="false">
        <label class="field">Overall assessment<input name="assessment" maxlength="220" value="${esc(monitor.assessment || "")}" required></label>
        <label class="field">Recommended risk rating<input name="recommendedRating" maxlength="80" value="${esc(monitor.rating?.recommended || "")}" required></label>
        <label class="field field-wide">Rating rationale <small>State support and contrary evidence. The Studio never assigns the rating.</small><textarea name="ratingRationale" rows="3" maxlength="2400" required>${esc(monitor.ratingRationale || "")}</textarea></label>
        <label class="field field-wide">PM conclusion and carry-forward actions <small>Full text stays in the review pack; the two-page monitor uses a bounded excerpt.</small><textarea name="conclusion" rows="4" maxlength="4000" required>${esc(monitor.conclusion || "")}</textarea></label>
        <label class="field">Officer output<select name="outputProfile"><option value="executive" ${monitor.outputProfile === "executive" ? "selected" : ""}>Compact two-page monitor</option><option value="standard" ${monitor.outputProfile === "standard" ? "selected" : ""}>Monitor + compact schedules</option><option value="full" ${monitor.outputProfile === "full" ? "selected" : ""}>Full monitor + appendices</option></select></label>
        <div class="field"><span>Optional detail in exported officer report</span><label class="check-line light"><input type="checkbox" name="includeFinancialTables" ${monitor.includeFinancialTables ? "checked" : ""}><span>Include financial-statement schedule</span></label><label class="check-line light"><input type="checkbox" name="includeBalanceSheetTable" ${monitor.includeBalanceSheetTable ? "checked" : ""}><span>Include balance-sheet schedule</span></label></div>
        <div class="field-wide monitor-profile-preview"><strong>${esc(profile.label)}</strong><span>Included: ${esc(profile.included.join(" · "))}</span><span>Omitted from officer output: ${esc(profile.omitted.join(" · ") || "Nothing")}</span><small>Omitted schedules remain available in the Studio and full review record.</small></div>
        <div class="field-wide right"><button class="button button-primary" type="submit">Save PM monitor decision</button></div>
      </form></section>`;
    }

    function schedulesPanel() {
      const financialRows = ttm.slice(-4);
      const balanceRows = balances.slice(-4);
      return `<details class="panel monitor-analysis" id="monitor-analysis-work"><summary class="panel-summary">Retained financial-statement and balance-sheet analysis</summary><div class="monitor-analysis-grid"><div class="table-wrap"><table class="data-table"><caption>TTM financial analysis</caption><thead><tr><th>Period</th><th>Revenue</th><th>Gross margin</th><th>Net income</th><th>Closings</th></tr></thead><tbody>${financialRows.map((item) => `<tr><td>${esc(formatDate(item.periodEnd))}</td><td>${esc(monitorValue(item.revenue, "money"))}</td><td>${esc(monitorValue(item.grossMargin, "percent"))}</td><td>${esc(monitorValue(item.netIncome, "money"))}</td><td>${esc(monitorValue(item.closings, "number", 0))}</td></tr>`).join("") || '<tr><td colspan="5">No TTM schedule was supplied.</td></tr>'}</tbody></table></div><div class="table-wrap"><table class="data-table"><caption>Quarterly balance-sheet analysis</caption><thead><tr><th>Period</th><th>Assets</th><th>Liabilities</th><th>TNW</th><th>Cross-foot</th></tr></thead><tbody>${balanceRows.map((item) => `<tr><td>${esc(formatDate(item.periodEnd))}</td><td>${esc(monitorValue(item.totalAssets, "money"))}</td><td>${esc(monitorValue(item.totalLiabilities, "money"))}</td><td>${esc(monitorValue(item.tangibleNetWorth, "money"))}</td><td>${esc(monitorValue(item.crossFootDifference, "money"))}</td></tr>`).join("") || '<tr><td colspan="5">No balance-sheet schedule was supplied.</td></tr>'}</tbody></table></div></div><div class="panel-body"><p class="muted">These schedules stay available for analysis whether or not the selected officer-output profile includes them.</p></div></details>`;
    }

    function controlPanel() {
      return `<details class="panel monitor-controls" id="monitor-control-work"><summary class="panel-summary">Exact monitor readiness controls (${gates.filter((gate) => gate.pass).length}/${gates.length} passing)</summary><div class="monitor-control-list">${gates.map((gate) => `<article><span class="tag ${gate.pass ? "good" : "bad"}">${gate.pass ? "Pass" : "Open"}</span><div><strong>${esc(gate.title)}</strong><p>${esc(gate.detail)}</p></div></article>`).join("")}</div></details>`;
    }

    if (stage === "add") {
      return `${pageHead("Quarterly monitor intake", `${monitor.identity?.borrower || state.deal?.borrower || "Borrower"} — source setup`, "Confirm the exact workbook, explicit review date and four source cutoffs before reviewing any conclusion.", '<button class="button button-primary" type="button" data-trigger-monitor>Replace workbook version</button>')}
        <section class="monitor-intake-shell"><div class="monitor-intake-lead"><span class="monitor-intake-mark" aria-hidden="true">Q</span><div><p class="eyebrow">Workbook intake</p><h3>${esc(monitor.profile || "Quarterly monitor")}</h3><p>Source ID ${esc(monitor.workbookSourceId || "Not bound")} · reporting period ${esc(formatDate(monitor.reportingPeriodEnd))}. Replacing the file supersedes the prior source version without erasing its audit history.</p></div></div><div class="monitor-intake-grid">${intake.map((item, index) => `<article class="monitor-intake-item ${item.complete ? "is-complete" : "is-open"}"><span>${item.complete ? "✓" : index + 1}</span><div><strong>${esc(item.label)}</strong><p>${esc(item.detail)}</p><small>${esc(item.owner)}</small></div></article>`).join("")}</div><div class="monitor-intake-actions"><div><strong>${intake.filter((item) => item.complete).length}/${intake.length} intake checks complete</strong><span>Continue to Confirm what matters for exception review.</span></div><button class="button button-quiet" type="button" data-trigger-checkpoint>Resume another checkpoint</button></div></section>
        ${cutoffStrip()}${coveragePanel()}<p class="muted mt-15">No application deal store, model call or outbound transfer is used. Workbook values remain candidates until the review controls are confirmed.</p>`;
    }

    if (stage === "verify") {
      return `${pageHead("Quarterly exception review", `${monitor.identity?.borrower || state.deal?.borrower || "Borrower"} — confirm what matters`, "Work the priority queue, then confirm the exact cutoffs, 14-field core, supplemental observations, formula diagnostics, covenants and reporting exceptions.", `<button class="button button-primary" type="button" data-confirm-monitor>${monitor.reviewed ? "Reconfirm extracted data & control review" : "Confirm extracted data & control review"}</button>`)}
        ${exceptionPanel(true)}${cutoffStrip()}${coveragePanel()}
        <div class="monitor-stage-stack">${covenantsAndReporting()}${actionsPanel()}${anomaliesPanel()}${controlPanel()}<details class="panel monitor-analysis"><summary class="panel-summary">Performance trends and retained analysis</summary><div class="panel-body">${metricsPanel()}${chartsPanel()}</div></details></div>
        <section class="monitor-confirm-bar"><div><strong>Confirmation does not erase exceptions.</strong><span>It accepts clean source-bound observations; unresolved warnings, actions and review controls stay visible.</span></div><button class="button button-primary" type="button" data-confirm-monitor>Confirm extracted data &amp; control review</button></section>`;
    }

    if (stage === "judgment") {
      return `${pageHead("PM monitoring conclusion", `${monitor.identity?.borrower || state.deal?.borrower || "Borrower"} — make the judgment explicit`, "Translate verified changes and exceptions into a rating rationale, conclusion, structured follow-up and an intentional officer-output profile.")}
        ${carryForwardPanel()}${exceptionPanel(false)}<div class="monitor-stage-stack">${actionsPanel()}${decisionForm()}${schedulesPanel()}</div>
        <p class="muted mt-15">The Studio organizes evidence and calculations; the portfolio manager owns the assessment, rating recommendation, contrary evidence and conclusion.</p>`;
    }

    return `${pageHead("Credit Officer quarterly review", `${monitor.identity?.borrower || state.deal?.borrower || "Borrower"} — ${formatDate(monitor.reportingPeriodEnd)}`, "Decision, movement, exceptions and accountability appear first. Detailed schedules and exact control results remain immediately available below.", '<button class="button button-quiet" type="button" data-print-monitor>Print / save PDF</button><button class="button button-primary" type="button" data-export-monitor>Download Word monitor</button>')}
      ${hero()}${carryForwardPanel()}${exceptionPanel(true)}
      <div class="monitor-review-profile"><div><p class="eyebrow">Officer output profile</p><h3>${esc(profile.label)}</h3><span>Included: ${esc(profile.included.join(" · "))}</span><span>Omitted: ${esc(profile.omitted.join(" · ") || "Nothing")}</span></div><div><strong>Analysis retained</strong><span>Financial statements, quarterly balance sheets, source observations and exact gates remain in the review record even when omitted from the officer output.</span></div></div>
      <div class="monitor-stage-stack"><div class="monitor-grid"><div class="span-2">${metricsPanel()}</div><section class="panel"><div class="panel-head"><div><p class="eyebrow">Accountability</p><h3>Open structured actions</h3></div><span class="tag ${carry.actions.length ? "warning" : "good"}">${carry.actions.length} open</span></div><div class="panel-body"><ul class="monitor-watch-list">${carry.actions.map((item) => `<li><span class="severity warning">action</span><div><strong>${esc(item.action)}</strong><p>${esc(item.evidence)}</p><small>${esc(item.owner)} · ${esc(formatDate(item.dueDate))}</small></div></li>`).join("") || "<li>No open structured actions.</li>"}</ul></div></section></div><details class="panel officer-supporting"><summary class="panel-summary">Covenants and reporting schedule</summary>${covenantsAndReporting()}</details><details class="panel officer-supporting"><summary class="panel-summary">Trend charts</summary><div class="panel-body">${chartsPanel()}</div></details>${schedulesPanel()}<details class="panel officer-supporting"><summary class="panel-summary">Workbook integrity and core evidence</summary><div class="panel-body">${coveragePanel()}${anomaliesPanel()}</div></details>${controlPanel()}</div>
      ${state.workflow === "portfolio_monitor" ? `<section class="monitor-confirm-bar"><div><strong>${monitor.officerDraftReviewed ? "Officer-facing draft reviewed" : "Finish the PM review of this officer-facing draft"}</strong><span>Confirm that the decision, exceptions, actions, rating movement and selected output profile are presented clearly before final controls.</span></div>${monitor.officerDraftReviewed ? '<span class="tag good">Review recorded</span>' : '<button class="button button-primary" type="button" data-confirm-monitor-officer>Mark officer draft reviewed</button>'}</section>` : ""}
      <p class="muted mt-15">Review Package Complete is not approval, a covenant waiver or an automated risk-rating decision. Missing values remain “Not provided,” and retained exceptions are never converted to clean prose.</p>`;
  }

  window.HBF_MonitorView = Object.freeze({ render });
})();
