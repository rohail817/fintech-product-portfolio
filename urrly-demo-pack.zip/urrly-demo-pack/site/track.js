/* Offline portfolio: activity tracking is disabled. */
