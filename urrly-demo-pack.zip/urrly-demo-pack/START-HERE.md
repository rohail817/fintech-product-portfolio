# Run the Urrly portfolio locally

1. Extract this ZIP fully.
2. With Node.js 22.18+ or 24+ installed, open a terminal in this folder and run `node start.mjs`.
3. Open http://localhost:8765/ in a browser.

Python alternative: open a terminal in the `site` folder, run `python3 -m http.server 8765 --bind 127.0.0.1` (Windows: `py -m http.server 8765 --bind 127.0.0.1`), then open the same address.

No package installation, account, API key or external data feed is needed. Double-clicking HTML files alone is insufficient because browser modules need HTTP. Closing the terminal stops the local server.

Start with Collateral Control for the rule engine and QPR Intelligence for workbook-to-review automation. All sample data is fictional. This local pack sends no activity events. HBF Intel is a development brief.

Independent work by Rohail Abid. 
